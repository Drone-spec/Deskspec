module.exports = {
  cld: require('cld'),
};
